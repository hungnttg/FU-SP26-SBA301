import React from "react";
import { Text, View, Image, StyleSheet, TouchableWithoutFeedback } from "react-native";

const Product = (props) => {
    const { dataProd = {} } = props;

    return (
        <View style={styles.container}>
            <TouchableWithoutFeedback>
                <View>
                    <Image
                        source={{ uri: dataProd.search_image }}
                        style={styles.image}
                    />
                    <Text>{dataProd.brands_filter_facet}</Text>
                    <Text>{dataProd.price}</Text>
                    <Text>{dataProd.product_additional_info}</Text>
                </View>
            </TouchableWithoutFeedback>
        </View>
    );
};

export default Product;

const styles = StyleSheet.create({
    container: {
        margin: 5, flex:1
    },
    image: {
        width: 200,
        height: 200,
        borderWidth: 1
    }
});
