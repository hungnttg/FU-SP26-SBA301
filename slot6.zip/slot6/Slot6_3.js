//thay doi kich thuoc man hinh
import { useEffect,useState } from "react";
export default function Slot6_3(){
    const [width,setWidth] = useState(window.innerWidth);
    useEffect(()=>{
        const handleResize = () => setWidth(window.innerWidth);
        window.addEventListener("resize",handleResize);
        //cleanup khi component unmount
        return () => {
            window.removeEventListener("resize",handleResize);
        };
    },[]);
    return(
        <div style={{padding:"30px"}}>
            <h1>Chieu rong man hinh la: {width}px</h1>
        </div>
    );
}