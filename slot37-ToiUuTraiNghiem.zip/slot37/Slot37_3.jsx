//ky thuat phan trang
import axios from "axios";
import React,{useEffect,useState} from "react";
export default function Slot37_3(){
    const [page,setPage]=useState(1);
    const [products,setProducts]=useState([]);
    useEffect(()=>{
        axios.get(`http://localhost:8080/api/products?page=${page}`)
        .then(res=>setProducts(prev => [...prev,...res.data]));
    },[page]);
    //giao dien
    return(
        <div>
            <ul>
                {products.map(p=><li key={p.id}>{p.tensanpham}</li>)}
            </ul>
            <button onClick={()=>setPage(p=>p+1)}>Tai them</button>
        </div>
    );
}
//khi nguoi dung nhan "Tai them", chi goi du lieu moi, trang qua tai UI