package com.example.slot15;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Slot15UserService {
    @Autowired
    private Slot15UserRepository repo;
    public List<Slot15User> getAll(){
        return repo.findAll();
    }
    public Optional<Slot15User> getById(String id){
        return repo.findById(id);
    }
    public Slot15User create(Slot15User u){
        return  repo.save(u);
    }
    public Slot15User update(String id,Slot15User u){
        return repo.findById(id).map(user -> {
            user.setName(u.getName());
            u.setBirthday(u.getBirthday());
            return repo.save(user);
        }).orElse(null);
    }
    public void xoa(String uid){
        repo.deleteById(uid);
    }
}
