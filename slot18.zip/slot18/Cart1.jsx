import React,{useState,useEffect} from "react";
//luu gio hang vaof client
export default function Cart1(){
    //lay du lieu tu localStorage khi load trang
    const [cart,setCart]=useState(()=>{
        const savedCart = localStorage.getItem("cart");//doc dulieu tu client
        return savedCart ? JSON.parse(savedCart) : [];//
    });
    //danh sach san pham
    const products = [
        {id:1,name:"Tao", price: 1000},
        {id:2,name:"Cam",price: 2000},
        {id:3,name:"Xoai",price: 3000}
    ];
    //moi lan cart thay doi => luu vao localStorage
    useEffect(()=>{
        localStorage.setItem("cart",JSON.stringify(cart));//luu
    },[cart]);
   //them san pham (neu co roi thi tang so luong) 
   const addItem = (product) =>{
    const exist = cart.find((item)=>item.id === product.id);
    if(exist){ //neu ton tai san pham => cong so luong them 1
        setCart(
            cart.map((item)=>
                item.id === product.id ? {...item, quantity: item.quantity+1} : item)
        );
    } else { //neu khong ton tai san pham => them san pham voi so luong la 1
        setCart([...cart,{...product,quantity:1}]);
    }
   };
   //giam so luong
   const giamSoLuongItem = (id) =>{
    setCart(
        cart
            .map((item) => 
                item.id === id ? {...item,quantity: item.quantity -1 } : item)
            .filter((item) => item.quantity > 0)
    );
   };
   //xoa han 1 san pham
   const xoaItem = (id) =>{
        setCart(cart.filter((item)=> item.id !== id));
   };
   //xoa toan bo gio hang
   const clearCart = () =>{
    setCart([]); //xoa trong chuong trinh
    localStorage.removeItem("cart");//xoa trong storage cuar nguoi dung
   };
   //return
   return(
    <div style={{padding: 30, fontFamily:"-apple-system"}}>
        <h1>Gio hang</h1>
        {/* danh sach san pham */}
        <h2>San pham</h2>
        {products.map((p)=>(
            <div key={p.id}>
                {p.name} - {p.price.toLocaleString()}d {" "}
                <button onClick={()=>addItem(p)}>Them</button>
            </div>
        ))}
        {/* gio hang */}
        <h2>Gio hang</h2>
        {cart.length === 0 ? (
            <p>Chua co san oham</p>
        ):(
            <table border="1" cellPadding="8">
                <thead>
                    <tr>
                        <th>Ten</th>
                        <th>Gia</th>
                        <th>So luong</th>
                        <th>Hanh dong</th>
                    </tr>
                </thead>
                <tbody>
                    {cart.map((item)=> (
                        <tr key={item.id}>
                            <td>{item.name}</td>
                            <td>{item.price.toLocaleString()}d</td>
                            <td>{item.quantity}</td>
                            <td>
                                <button onClick={()=>addItem(item)}>+</button>
                                <button onClick={()=>giamSoLuongItem(item.id)}>-</button>
                                <button onClick={()=> xoaItem(item.id)}>Xoa</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        )}
        {cart.length > 0 && (<button onClick={clearCart}>Xoa het gio hang</button>)}
    </div>
   );
}