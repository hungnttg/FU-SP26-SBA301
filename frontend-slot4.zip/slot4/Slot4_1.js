import { useEffect,useState } from "react";
export default function Slot4_1(){
    const [sp,setSp]=useState([]);//khoi tao mang chua du lieu
    //doc du lieu tu API
    useEffect(()=>{
        fetch("http://localhost:8080/slot4/api/sanpham/get")//doc du lieu
        .then(r => r.json()) //chuyen sang json
        .then(setSp) //dua vao mang da khoi tao
        .catch(e => console.error("Loi: ",e));
    },[]);
    //hien thi du lieu
    return(
        <div style={{padding:20}}>
            <h1> List dan pham</h1>
            {!sp.length ? "Dang tai..." : (
                <div style={{display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 30}}>
                    {/* vong lap */}
                    {sp.map(s=> (
                        <div key={s.id} style={{border:"1px slid #ccc",padding:10, borderRadius:10}}>
                            <img src={s.hinhanhsanpham} alt={s.tensanpham}
                                style={{width:"100%",height:200, objectFit:"cover"}} />
                            <h2>{s.tensanpham}</h2>
                            <p><b>Gia: </b>{s.giasanpham.toLocaleString()} VND</p>
                            <p>{s.motasanpham.slice(0,100)}...</p>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}