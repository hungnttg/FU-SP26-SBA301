package com.example.slot15;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot15user")
@CrossOrigin(origins = "http://localhost:3000")
public class Slot15UserController {
    @Autowired
    private Slot15UserService service;
    @GetMapping
    public List<Slot15User> getAll(){
        return service.getAll();
    }
    @GetMapping("/{id}")
    public Slot15User getById(@PathVariable String id){
        return service.getById(id).orElse(null);
    }
    @PostMapping
    public Slot15User create(@RequestBody Slot15User u){
        return service.create(u);
    }
    @PutMapping("/{id}")
    public Slot15User update(@PathVariable String id,@RequestBody Slot15User u){
        return service.update(id,u);
    }
    @DeleteMapping("/{id}")
    public String xoa(@PathVariable String id){
        service.xoa(id);
        return "Deleted id="+id;
    }
}
