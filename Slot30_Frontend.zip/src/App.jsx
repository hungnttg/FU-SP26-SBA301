import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import heroImg from './assets/hero.png'
import './App.css'
import Dashboard from './components/Dashboard'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ShopList from './components/ShopList'
import ShopDetail from './components/ShopDetail'

function App() {
  const [count, setCount] = useState(0)

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ShopList/>}/>
        <Route path="/view/:id" element={<ShopDetail/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App
