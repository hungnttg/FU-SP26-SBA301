//su dung trinh toi uu anh tich hop (resize, webp, lazy load)
import Image from "next/image";
export default function ImageDemo(){
    return(
        <main style={{padding:20}}>
            <h1>Demo mo to uu anh</h1>
            <Image src="https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d"
            alt=" Canh"
            width={600} height={400} quality={74} priority style={{borderRadius:'10px'}}/>
            <p>Anh nen, responsive, lazy load tu dong</p>
        </main>
    );
}