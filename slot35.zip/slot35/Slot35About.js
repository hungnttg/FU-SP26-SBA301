import React from "react";

export default function Slot35About(){
    return(
        <div>
            <h1>Day la trang About</h1>
        </div>
    );
}