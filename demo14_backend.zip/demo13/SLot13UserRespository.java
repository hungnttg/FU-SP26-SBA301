package com.example.demo13;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SLot13UserRespository extends JpaRepository<Slot13User, Long> {
}
