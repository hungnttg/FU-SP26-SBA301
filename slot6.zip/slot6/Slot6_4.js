//xu ly loi khi doc du lieu tu API
import { useEffect,useState } from "react";
export default function Slot6_4(){
    //code
    const [error,setError]=useState(null);
    const [users,setUsers]=useState([]);
    const [loading, setLoading]=useState(true);
    //load du lieu
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((res)=>{
            if(!res.ok) throw new Error("Looi khi fetch du lieu");
            return res.json();
        })
        .then((data)=>setUsers(data))
        .catch((err)=>setError(err.message))
        .finally(()=>setLoading(false));
    },[]);
    //layout
    if(loading) return <h2>Dang tai du lieu....</h2>
    if(error) return <h2 style={{color:"red"}}>Loi: {error}</h2>
    return(
        <div style={{padding:"30px"}}>
            <h1>Danh sach nguoi dung</h1>
            <ul>
                {users.map((u)=>(
                    <li key={u.id}>
                        {u.name} - {u.email}
                    </li>
                ))}
            </ul>
        </div>
    );
}