//amj responsive, co placeholder de blur, tang trai nghieemj
//next se tu dong chonj hinh anh dang webp, avif neu trinh duyet ho tro
import Image from "next/image";
export default function ImageAdvanced(){
    return(
        <main style={{padding:20}}>
            <h1>Demo toi uu hinh anh nang cao</h1>
            <Image src="https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d"
                alt="Phong canh"
                width={400}
                height={400}
                quality={100}
                placeholder="blur"
                blurDataURL="https://placehold.co/400"
                style={{borderRadius:'12px',maxWidth:'100%',height:'auto'}}/>
        </main>
    );
}