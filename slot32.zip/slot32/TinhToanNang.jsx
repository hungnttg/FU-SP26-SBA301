import React,{useMemo} from "react";
//gia lap tinh toan nang
const TinhToanNang = ({items}) =>{
    console.log('Render tinh toan nang');
    //useMemo giup tinh toan chi khi items thay doi
    const renderedList = useMemo(()=>{
        return items.map((item,index)=> <li key={index}>{item}</li>)
    },[items]);
    //giao dien
    return(
        <div>
            <h3>Tinh toan nang</h3>
            <ul>{renderedList}</ul>
        </div>
    );
};
export default TinhToanNang;