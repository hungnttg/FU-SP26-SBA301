//xu ly trang thai on/off
import React, {useState} from "react";
export default function Slot7_1(){
    //code
    const [isOn,setIsOn]=useState(false);
    //layout
    return(
        <div>
            <h2>Trang thai: {isOn ? "Bat" : "Tat"}</h2>
            <button onClick={()=>setIsOn(!isOn)}>
                {isOn ? "Tat" : "Bat"}
            </button>
        </div>
    );
}