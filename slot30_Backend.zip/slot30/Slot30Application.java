package com.example.slot30;

import com.example.slot22crud.Slot22Application;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot30Application {
    public static void main(String[] args) {
        SpringApplication.run(Slot30Application.class,args);
    }
}
