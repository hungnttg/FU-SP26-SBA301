import React from "react";
export default function VD2_Con(props){
    return(
        <div>
            <h2>{props.message}</h2>
        </div>
    );
}