package com.example.demo.slot14;

import com.example.demo.DemoApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot14DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(Slot14DemoApplication.class, args);
    }
}
