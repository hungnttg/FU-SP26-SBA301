//dinh nghia thanh phan con
export default function Slot_3_2_Con({children}){
    return(
        <div style={{border:"1px solid gray",padding:"10px", margin:"10px"}}>
            {/* goi props */}
            {children}
        </div>
    );
}