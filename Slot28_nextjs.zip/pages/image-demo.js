import Image from "next/image";
//lazy load tu dong
export default function ImageDemo(){
    return(
        <main style={{padding:20}}>
            <h1>Demo toi uu hinh anh</h1>
            <Image
                src="https://images.unsplash.com/photo-1761602545461-7c9bd9a986df?q=80&w=1311&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                alt="Phong canh"
                width={600}
                height={400}
                quality={100}
                priority
                style={{borderRadius:'15px'}}

            />
            <p>Anh nay duoc nen va responsive, lazy load tu dong</p>
        </main>
    );
}