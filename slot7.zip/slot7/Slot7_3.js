//thay doi phan tu trong list
import React,{useState} from "react";
export default function Slot7_3(){
    const [list, setList]=useState([]);
    const [task,setTask]=useState("");
    const addTask = () =>{
        if(task.trim()==="") return;
        setList([...list,task]);//them task vaof list
        setTask("");//reset task
    };
    const removeTask = (index) => {
        setList(list.filter((_,i) => i !== index));
    };
    //layout
    return(
        <div>
            <h2>Todo list</h2>
            <input
                type="text"
                value={task}
                onChange={(e)=>setTask(e.target.value)}
                placeholder="Nhap cong viec"
            />
            <button onClick={addTask}>Them</button>
            {/* danh sach cong viec da them */}
            <ul>
                {list.map((item,index)=>(
                    <li key={index}>
                        {item} <button onClick={()=>removeTask(index)}>Xoa</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}