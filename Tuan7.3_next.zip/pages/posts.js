//pages/posts.js
//toi uu load trang bang static generation + ISR
//chu y: ISR: cap nhat du lieu dinh ky ma khong reload toan bo
//SSR: chi dung khi thay doi du liei lien tuc
export async function getStaticProps(){
    const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=5');
    const posts = await res.json();
    return {
        props: {posts},
        revalidate: 60, //tai tao sau 60s
    };
}
export default function PostsPage({posts}){
    return(
        <main style={{padding:20}}>
            <h1>Danh sach bai viet</h1>
            <ul>
                {posts.map((p)=>(
                    <li key={p.id}>
                        <strong>{p.title}</strong>
                        <p>{p.body}</p>
                    </li>
                ))}
            </ul>
        </main>
    );
}