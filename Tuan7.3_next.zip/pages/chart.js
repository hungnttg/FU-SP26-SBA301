//pages/chart.js
//dynamic import (luoi load coponent nang)=> chi tai component khi can
//=> giam dung luong component
import dynamic from "next/dynamic";
import { useState } from "react";
//import Chart khi nguoi dung nhan nut (lazy load)
const Chart = dynamic(()=>import('../components/Chart'),{ssr:false});
export default function ChartPage(){
    const [showChart,setShowChart]=useState(false);
    return(
        <main style={{padding:20}}>
            <h1>Dynamic Import</h1>
            <button onClick={()=>setShowChart(true)}>Hien bieu do</button>
            {showChart && <Chart/>}
        </main>
    );
}