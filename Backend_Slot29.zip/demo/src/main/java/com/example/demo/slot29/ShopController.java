package com.example.demo.slot29;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot29/shops")
@CrossOrigin(origins = "http://localhost:5173")
public class ShopController {
    @Autowired
    private ShopRepository repo;
    @GetMapping
    public List<Shop> getAll(){
        return repo.findAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Shop> getById(@PathVariable Long id){
        return repo.findById(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Shop create(@RequestBody Shop shop){
        return repo.save(shop);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Shop> update(@PathVariable Long id,@RequestBody Shop s){
        return repo.findById(id).map(shop ->{
            shop.setShopName(s.getShopName());
            shop.setOwner(s.getOwner());
            shop.setType(s.getType());
            shop.setOpenTime(s.getOpenTime());
            return ResponseEntity.ok(repo.save(shop));
        }).orElse(ResponseEntity.notFound().build());
    }
    @GetMapping("/types")
    public List<String> getTypes(){
        return List.of("Science","Math","Computer Science");
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        repo.deleteById(id);
        return ResponseEntity.ok().build();
    }
}
//Yeu cau:
//su dung backend nay, viet front end
//Su dung vite (npm create vite@latest TenDuAn --template react
//Nen de cau truc thu muc (chu y: di thi thi can xem de cu the)
//src/
    //component/
        //ShopList.jsx
        //ShopForm.jsx
        //ShopDetail.jsx
    //app.jsx
    //main.jsx
//jsconfig.json
//chu y: giao dien lam tuy y (khi di thi can nhin giao dien ma de cung cap)
