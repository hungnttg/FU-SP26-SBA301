import React from "react";
const LoadingSpinner = () =>{
    return(
        <div style={{textAlign:'center',marginTop:'50px',
            width:'50px',
                height:'50px',
                border: '5px solid #ccc',
                borderTop: '5px solid #bbb',
                borderRadius:'50%',
                animation:'spin 1s linear infinite'
        }}>
            <p>Dang tai....</p>        
            <style>
                {
                    `
                        @keyframes spin {
                            0% {transform: rotate(0deg);}
                            100% {transform: rote(360deg);}
                        }
                    `
                }
            </style>
        </div>
    );
};
export default LoadingSpinner;