export default function Dashboard(){
    return(
        // flex: hien thi ngang
        //min-h-screen: chieu cao toi thieu 100vh
        //bg-gray-100: nen xam nhat
        <div className="flex min-h-screen bg-gray-100">
            {/* w-60: width=240px; bg-blue-800; text-white p-4: padding */}
            <aside className="w-60 bg-blue-800 text-white p-4">
                <h2 className="text-xl font-bold mb-8">NexaCloud</h2>
                <nav className="space-y-2 bg-blue-500">
                    <a href="#" className="block bg-blue-700 p-2 rounded">Dashboard</a>
                    <a href="#" className="block p-2 hover:bg-blue-700 rounded">Nguoi dung</a>
                    <a href="#" className="block p-2 hover:bg-blue-700 rounded">Du an</a>
                    <a href="#" className="block p-2 hover:bg-blue-700 rounded">Bao cao</a>
                    <a href="#" className="block p-2 hover:bg-blue-700 rounded">Cai dat</a>
                </nav>
                <div className="absolute bottom-4">
                    <p className="font-medium">Admin Tuan</p>
                    <p className="text-sm text-gray-300">Super Admin</p>
                </div>
            </aside>
            {/* content */}
            <main className="flex-1 p-6">
                {/* header */}
                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h2 className="text-2xl font-bold">Dashboard tong quan</h2>
                        <p className="text-gray-500">Thu 3, 28 thang 4, 2026</p>
                    </div>
                    <button className="bg-blue-500 text-white px-4 py-2 rounded">+ Tao moi</button>
                </div>
                {/* card */}
                <div className="grid grid-cols-4 gap-4 mb-6">
                    {[
                        ["Tong doanh thu","4.2 ty"],
                        ["Nguoi dung moi","1284"],
                        ["DU an dang chay","37"],
                        ["Ty le giu chan","94.2%"],
                    ].map(([title,value])=>(
                        <div key={title} className="bg-white p-4 rounded shadow">
                            <p className="text-gray-500 text-sm">{title}</p>
                            <h3 className="text-2xl font-bold">{value}</h3>
                        </div>
                    ))}
                </div>
                {/* 
                    tailwind        css
                    flex            display:flex
                    grid            display:grid
                    flex-1          flex:1
                    justify-between justify-content:space-between
                    items-center    align-items:center
                    items-end       align-items:flex-end
                    bg-white        backbground:white
                    bg-blue-500     nen xanh
                    p-4             padding: 16px
                    p-6             6x4=24px
                    px-4            padding-left/right: 16px
                    py-2            padding-top/bottom: 8px
                    mb-4            margin-bottom: 16px
                    rounded         border-radius
                    shadow          
                    w-60            width
                    h-48            heght
                    grid-cols-4
                    gap-4           16px
                    text-sm
                    text-xl
                    text-2xl
                    
                */}
            </main>
        </div>
    );
}
