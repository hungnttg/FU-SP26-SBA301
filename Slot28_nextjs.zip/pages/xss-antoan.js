"use client";
import { useState } from "react";
//npm i dompurify
import DOMPurify from "dompurify";
export default function XSSSafe(){
    const [comment,setComment]=useState("");
    return(
        <div>
            <h2>Binh luan an toan</h2>
            <input
                type="text"
                placeholder="Nhap binh luan"
                onChange={(e)=>setComment(e.target.value)}
            />
            <p>Hien thi binh luan</p>
            {/* lam sach du lieu truoc khi render */}
            <div 
                dangerouslySetInnerHTML={{__html:DOMPurify.sanitize(comment),}}
            />
        </div>
    );
}
//DOMPirify.sanitize(comment) => loai bo cac doan ma nguy hiem
//ngoai ra co the áp dụng một số cách khác:
//không dùng dangerouslySetInnerHTML trừ khi bắt buộc
//nên dùng textContent thay vì innerHTML
