package com.example.slot31;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot31Application {
    public static void main(String[] args) {
        SpringApplication.run(Slot31Application.class,args);
    }
}
