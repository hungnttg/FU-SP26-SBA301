import { Link, useParams } from "react-router-dom";
export default function ProductDetail(){
    const {id}=useParams();//lay id truyen sang tu trang san pham
    return(
        <div className="container">
            <h1>Chi tiet san pham</h1>
            <p>ID san pham: {id}</p>
        </div>
    );
}