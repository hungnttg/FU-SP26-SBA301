export default function Home(){
    return(
        <div>
            <h2>Welcome to My Website</h2>
            <p>This sis the homepage content</p>
        </div>
    );
}