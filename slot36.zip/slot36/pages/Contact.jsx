//lazy load
import React from "react";
const Contact = () => {
    return(
        <div>
            <h1>Congtact Page</h1>
            <p>This page is lazt loaded.</p>
        </div>
    );
}
export default Contact;