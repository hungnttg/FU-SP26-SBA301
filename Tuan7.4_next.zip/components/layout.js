import Link from "next/link";
import React from "react";
export default function Layout({children}){
  const menus = [
    {title:"Home",href:"/"},
    {
      title: "Pages",
      children: [
        {title: "About",href:"/about"},
        {title: "Blog", href:"/blog"},
        {title: "Posts", href:"/posts"}
      ],
    },
    {
      title: "Images",
      children:[
        {title: "Image Demo",href:"/image-demo"},
        {title: "Image Advance",href: "/image-advance"},
        {title: "Prefetch Demo",href: "/prefetch-demo"},
      ],
    },
  ];
  return(
    <div style={{fontFamily:"Arial,sans-serif"}}>
      <header style={{backgroundColor:"#f1f1f1",padding:"15px"}}>
        <nav style={{display:"flex",gap:"20px"}}>
          {menus.map((m,i)=> m.href ? (
            <Link key={i} href={m.href}>{m.title}</Link>
          ) : (
            <details key={i}>
              <summary>{m.title}</summary>
              <div style={{display:"flex",flexDirection:"column"}}>
                {m.children.map((c,j)=>(
                  <Link key={j} href={c.href}>{c.title}</Link>
                ))}
              </div>
            </details>
          ))}

          {/* <Link href="/">Home</Link>
          <Link href="/about">About</Link>
          <Link href="/blog">Blog</Link>
          <Link href="/posts">Posts</Link>
          <Link href="/chart">Chart</Link>
          <Link href="/prefetch-demo">Prefetch Demo</Link>
          <Link href="/image-demo">Image Demo</Link>
          <Link href="/image-advance">Image Advance</Link> */}
        </nav>
      </header>
      <main style={{padding:"20px"}}>{children}</main>
      <footer style={{padding:"10px",backgroundColor:"#f0f0f0",marginTop:"20px"}}>
        &copy; 2026 My Website
      </footer>
    </div>
  );
}