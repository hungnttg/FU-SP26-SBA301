//su dung map trong React
export default function Slot3_3(){
    //khai bao 1 mang
    const students = [
        {id:1, name: "An", age:21},
        {id:2, name:"Hung",age:22},
        {id:3,name:"Chung",age:20},
    ];
    //render
    return(
        <div>
            <h1>Sanh sach sinh vien</h1>
            {/* vong lap */}
            {students.map((s)=>(
                <div key={s.id}>
                    <p>{s.name} - {s.age}</p>
                </div>
            ))}
        </div>
    );
}