export default function Slot1_1(){
    //khai bao 1 danh sach
    const students = ["An","Binh","Chung","Dung"];
    //hien thi danh sach
    return(
        <div>
            <h2>Danh sach sinh vien</h2>
            {/* vong lap */}
            <ul>
                {students.map((s,index)=>(
                    <li key={index}>{s}</li>
                ))}
            </ul>
        </div>
    );
}