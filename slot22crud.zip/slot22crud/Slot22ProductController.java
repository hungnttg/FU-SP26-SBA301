package com.example.slot22crud;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot22/products")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class Slot22ProductController {
    private final Slot22Repository repo;
    @GetMapping
    public List<Slot22Product> getAll(){
        return repo.findAll();
    }
    @PostMapping
    public Slot22Product add(@RequestBody Slot22Product p){
        return repo.save(p);
    }
    @PutMapping("/{id}")
    public Slot22Product update(@PathVariable Long id, @RequestBody Slot22Product p){
        p.setId(id);
        return repo.save(p);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id){
        repo.deleteById(id);
    }
}
