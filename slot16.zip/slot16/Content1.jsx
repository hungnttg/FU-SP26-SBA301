import React,{useEffect,useState} from "react";
function Content1(){
    const [posts,setPosts]=useState([]);
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts")
        .then((res)=>res.json())
        .then((data)=>setPosts(data.slice(0,5)))//lay 5 bai
        .catch((err)=> console.error("Error fetching data: ",err));
    },[]);
    return(
        <section className="content-box">
            <h2>Content Section 1</h2>
            <ul className="post-list">
                {posts.map((post)=>(
                    <li key={post.id} className="post-item">
                        <h3>{post.title}</h3>
                        <p>{post.body}</p>
                    </li>
                ))}
            </ul>
        </section>
    );
}
export default Content1;