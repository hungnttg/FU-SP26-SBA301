import Image from "next/image";
import { getPlaiceholder } from "plaiceholder";
export async function getStaticProps() {
    
    const url = "https://images.unsplash.com/photo-1761602545461-7c9bd9a986df?q=80&w=1311&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";
    const kq = await fetch(url);
    const bodem = await kq.arrayBuffer();
    const {base64,img} = await getPlaiceholder(Buffer.from(bodem));
    return {
        props: {
            
            src: url,
            blurDataURL: base64,
            
        },
    };
}
export default function ImageThuVien({src,blurDataURL}){
    return(
        <main style={{padding:20}}>
            <h1>Demo anh mang voi blur</h1>
            <Image
                src={src}
                width={400}
                height={400}
                alt="Phong canh"
                placeholder="blur"
                blurDataURL={blurDataURL}
                style={{borderRadius:"13px",maxWidth:"100%",height:"auto"}}
            />
        </main>
    );
}