import React from "react";
import Header from "./slot16/Header";
import Footer from "./slot16/Footer";
import Content1 from "./slot16/Content1";
import Content2 from "./slot16/Content2";
import "./App.css";

function App() {
  return (
    <div className="app-container">
      <Header/>
      <main className="main-content">
        <Content2/>
        <Content1/>
        
      </main>
      <Footer/>
    </div>
  );
}

export default App;
