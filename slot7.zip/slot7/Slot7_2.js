//quan ly form
import React,{useState} from "react";
export default function Slot7_2(){
    //code
    const [form,setForm]=useState({name:"",email:""});
    //dinh nghia ham thay doi gia tri
    const handleChange = (e) =>{
        setForm({
            ...form, [e.target.name]: e.target.value,
        });
    };
    //ham submit
    const handleSubmit = (e) =>{
        e.preventDefault();
        alert(`Name: ${form.name}, Email: ${form.email}`);
    };
    //layout
    return(
        <form onSubmit={handleSubmit}>
            <h2>Form User</h2>
            <input
                type="text"
                name="name"
                placeholder="Nhap ten"
                value={form.name}
                onChange={handleChange}
            />
            <br/>
            <input 
                type="email"
                name="email"
                placeholder="Nhap email"
                value={form.email}
                onChange={handleChange}
            />
            <br/>
            <button type="submit">Submit</button>
        </form>
    );
}