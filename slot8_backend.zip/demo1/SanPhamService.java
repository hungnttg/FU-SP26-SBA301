package com.example.demo1;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

@Service
public class SanPhamService {
    private final SanPhamRepository repo;
    public SanPhamService(SanPhamRepository repo){
        this.repo=repo;
    }
    public List<SanPham> findAll(){return repo.findAll();}
    public Optional<SanPham> findById(Integer id){
        return repo.findById(id);
    }
    public SanPham save(SanPham sp){return repo.save(sp);}
    public void deleteById(Integer id){repo.deleteById(id);}
}
