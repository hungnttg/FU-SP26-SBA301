//su dung useCallback
import React,{useState,useCallback} from "react";
import ProductList from './Slot37_1';
export default function Slot37_2(){
    const [filter,setFilter]=useState("");
    const handleSearch = useCallback((e)=>{
        setFilter(e.target.value);
    },[]);
    //giao dien
    return(
        <div className="p-4">
            <input placeholder="Tim san pham..." onChange={handleSearch}/>
            <ProductList filter={filter}/>
        </div>
    );
}