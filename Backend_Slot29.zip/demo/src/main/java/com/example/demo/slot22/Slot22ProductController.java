package com.example.demo.slot22;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3001")
@RestController
@RequestMapping("/slot22/products")
public class Slot22ProductController {
    private List<Slot22Product> products = List.of(
            new Slot22Product(1,"San pham 1",1200),
            new Slot22Product(2, "san pham 2",888),
            new Slot22Product(3,"Dien thoai Xiaomi",333)
    );
    @GetMapping
    public List<Slot22Product> getAll(){
        return products;
    }
}
