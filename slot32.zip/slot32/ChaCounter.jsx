import React,{useState,useCallback,useTransition,Suspense,lazy, startTransition} from "react";
import Counter from "./Couter";
import TinhToanNang from "./TinhToanNang";
import LoadingSpinner from "./LoadingSpinner";
//lazy loading 1 component
const LazyComponent = lazy(()=>import('./LoadingSpinner'));
export default function ChaCounter(){
    const [count,setCount]=useState(0);
    const [items,setItems]=useState([]);
    //dinh nghia ham tang
    const handleIncrement = useCallback(()=>{
        setCount(prev => prev +1);
    },[]);
    //ham handleAddItems
    const handleAddItems = () =>{
        startTransition(()=>{
            const newItems =Array.from({length:1000},(_,i) => `Item ${i+1}`);
            setItems(newItems);
        });
    };
    //giao dien
    return(
        <div style={{padding:'20px'}}>
            <Counter count={count} onIncrement={handleIncrement}/>
            <hr/>
            {/* su dung useTransition + useMemo */}
            <button onClick={handleAddItems}>
                Add 1000 items (Heavy Computation)
            </button>

            <TinhToanNang items={items} />
            <hr/>
            {/* lazy loading component */}
            <Suspense fallback={<LoadingSpinner/>} >
                <LazyComponent/>
            </Suspense>
        </div>
    );
}