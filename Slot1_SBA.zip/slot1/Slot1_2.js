import { useState } from "react";
export default function Slot1_2(){
    //khai bao bien quan ly trang thai
    const [name,setName]=useState("");//tuong tu bien toan cuc o ngoai ham
    // thiet ke o nhap lieu va hien thi du lieu nhap
    return(
        <div>
            <h2>Nhap ten cua ban</h2>
            <input
                type="text"
                placeholder="Nhap ten..."
                value={name}
                onChange={(e)=>setName(e.target.value)}
            />
            <p>Xin chao {name || "ban chua nhap ten"}</p>
        </div>
    );
}