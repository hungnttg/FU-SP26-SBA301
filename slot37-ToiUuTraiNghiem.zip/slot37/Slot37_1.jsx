//tối ưu render danh sách sản phẩm
import React,{memo} from "react";
const ProductItem = memo(({product})=>{
    console.log("Render: ",product.tensanpham);
    return <li>{product.tensanpham} - {product.giasanpham}d</li>
});
export default ProductItem;