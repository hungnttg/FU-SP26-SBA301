import { useEffect,useState } from "react";
import { useNavigate, useNavigation } from "react-router-dom";
import { Modal,Form,Button,Table } from "react-bootstrap";
import axios from "axios";
export default function ShopList(){
    const API = "http://localhost:8081/slot31/shops";
    const navigate = useNavigate();
    //shop
    const [shops,setShops]=useState([]);
    //form
    const [form,setForm]=useState({shopName:"",owner:"",type:"",openTime:""});
    const [show,setShow]=useState(false);//hien thi
    const [types,setTypes]=useState([]);
    const [deleteId,setDeleteId]=useState(null);
    //ham doc du lieu
    useEffect(()=>{
        loadData();
        axios.get("http://localhost:8081/slot31/shops/types")
        .then(res=>setTypes(res.data));//doc Combobox
    },[]);
    //dinh nghia loadData
    const loadData = () => axios.get(API).then(res=>setShops(res.data));
    //ham them du lieu
    const handleAdd = () =>{
        if(!form.shopName || !form.type || !form.owner || !form.openTime){
            alert("Hay nhap du du lieu");
            return;
        }
        axios.post(API,form).then(()=>{
            alert("Them thanh cong");
            loadData();//reload du lieu
        })
    };
    const handleXoa = () =>{
        axios.delete(`${API}/${deleteId}`).then(()=>{
            alert("Xoa thanh cong");
            setShow(false);
            loadData();
        });
    };
    const confirmDelete = (id) =>{
        setDeleteId(id);
        setShow(true);
    };
    //giao dien: lam giong giao dien nhu trong de
    return(
        <div className="container mt-3">
            <h2>Quan ly shop sach</h2>
            {/* form nhap lieu o day */}
            <Form className="mb-3">
                <Form.Control
                    className="mb-2"
                    placeholder="Nhap Shop name"
                    value={form.shopName}
                    onChange={(e)=>setForm({...form,shopName:e.target.value})}
                />
                <Form.Select
                    className="mb-2"
                    value={form.type}
                    onChange={(e)=>setForm({...form,type:e.target.value})}>
                   <option value="">Select Type</option>     
                   {types.map(t=> <option key={t}>{t}</option>)}
                </Form.Select>
                <Form.Control
                    className="mb-2"
                    placeholder="Nhap Open Time"
                    type="number"
                    value={form.openTime}
                    onChange={(e)=>setForm({...form,openTime:e.target.value})}
                />
                <Form.Control
                    className="mb-2"
                    value={form.owner}
                    onChange={(e)=>setForm({...form,owner:e.target.value})}
                />
                <Button onClick={handleAdd}>Add New</Button>
            </Form>
            {/* bang hien thi du lieu */}
            <Table bordered>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ShopName</th>
                        <th>Type</th>
                        <th>Owner</th>
                        <th>OpenTime</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {shops.map((sh,i)=>(
                        <tr key={sh.id}>
                            <td>{i+1}</td>
                            <td>{sh.shopName}</td>
                            <td>{sh.type}</td>
                            <td>{sh.owner}</td>
                            <td>{sh.openTime}</td>
                            <td>
                                <Button variant="danger" size="sm"
                                onClick={()=>confirmDelete(sh.id)}>Delete</Button>{" "}
                                <Button variant="info" size="sm"
                                onClick={()=>navigate(`/view/${sh.id}`)}>View</Button>{" "}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
            <Modal show={show} onHide={()=>setShow(false)}>
                <Modal.Header closeButton>
                     <Modal.Title>Confirm</Modal.Title>   
                </Modal.Header>
                <Modal.Body>Co chac xoa khong?</Modal.Body>
                <Modal.Footer>
                    <Button onClick={handleXoa}>Yes</Button>
                    <Button variant="secondary" onClick={()=>setShow(false)}>Close</Button>
                </Modal.Footer>
            </Modal>
            
        </div>
    );
}
