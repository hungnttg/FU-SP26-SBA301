import React from "react";
const LoadingSpinner = () => (
    <div style={{textAlign:'center',margin:'20px'}}>
        <p>Loading....</p>
    </div>
);
export default LoadingSpinner