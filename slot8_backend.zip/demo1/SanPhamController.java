package com.example.demo1;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:3000")
public class SanPhamController {
    private final SanPhamService service;
    public SanPhamController(SanPhamService service){
        this.service=service;
    }
    @GetMapping
    public List<SanPham> getAll(){
        return service.findAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<SanPham> getById(@PathVariable Integer id){
        return service.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public ResponseEntity<SanPham> create(@RequestBody SanPham sp){
        SanPham saved = service.save(sp);
        return ResponseEntity.ok(saved);
    }
    @PutMapping("/{id}")
    public ResponseEntity<SanPham> update(@PathVariable Integer id,
        @RequestBody SanPham sp){
            return service.findById(id)
            .map(existing -> {
                existing.setTensanpham(sp.getTensanpham());
                existing.setGiasanpham(sp.getGiasanpham());
                existing.setHinhanhsanpham(sp.getHinhanhsanpham());
                existing.setMotasanpham(sp.getMotasanpham());
                existing.setIdsanpham(sp.getIdsanpham());
                SanPham updated = service.save(existing);
                return ResponseEntity.ok(updated);
            }).orElse(ResponseEntity.notFound().build());
        }
        @DeleteMapping("/{id}")
        public ResponseEntity<Void> delete(@PathVariable Integer id){
            service.deleteById(id);
            return ResponseEntity.noContent().build();
        }
}
