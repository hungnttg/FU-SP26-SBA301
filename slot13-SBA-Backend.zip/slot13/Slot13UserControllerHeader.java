package com.example.t1.slot13;


import org.springframework.web.bind.annotation.*;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/slot13/users")
@CrossOrigin(origins = "http://localhost:3000") // cho phép ReactJS
public class Slot13UserControllerHeader {

    @GetMapping(headers = "X-API-VERSION=1")
    public List<Slot13User> getUsersV1() {
        return Arrays.asList(
                new Slot13User(1L, "John", "john@example.com"),
                new Slot13User(2L, "Jane", "jane@example.com")
        );
    }

    @GetMapping(headers = "X-API-VERSION=2")
    public List<Slot13User> getUsersV2() {
        return Arrays.asList(
                new Slot13User(1L, "John", "JOHN@EXAMPLE.COM"),
                new Slot13User(2L, "Jane", "JANE@EXAMPLE.COM")
        );
    }
}