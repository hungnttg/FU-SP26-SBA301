import React,{useState,useEffect} from "react";
import Student from "./VD4_Con";
export default function VD4_Cha(){
    //code
    const [students,setStudents]=useState([]);
    //goi API
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((res)=>res.json())
        .then((data)=>setStudents(data))
        .catch((err)=>console.error(err));
    },[]);
    //layout
    return(
        <div>
            <h1>Danh sach sinh vien</h1>
            {students.map((s)=>(
                <Student
                    key={s.id}
                    name={s.name}
                    email={s.email}
                    company={s.company?.name}
                />
            ))}
        </div>
    );
}