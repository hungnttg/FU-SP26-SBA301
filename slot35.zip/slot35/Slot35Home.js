import React from "react";

export default function Slot35Home(){
    return(
        <div>
            <h1>Day la trang Home</h1>
        </div>
    );
}