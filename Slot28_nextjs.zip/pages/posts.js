//toi uu load trang bang SSG + ISR
//SSR: chi dung chi du lieu thay doi lien tuc
//ISR: cap nhat dinh ky ma khong reload toan bo
export async function getStaticProps(){
    const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=5');
    const posts = await res.json();//chuyen sang json
    return {
        props: {posts},
        revalidate: 60, //tai tao lai sau 60s
    };
}
export default function PostsPage({posts}){
    return(
        <main style={{padding:20}}>
            <h1>Danh sach bai viet</h1>
            <ul>
                {posts.map((p)=>(
                    <li key={p.id}>
                        <strong>{p.title}</strong>
                        <p>{p.body}</p>
                    </li>
                ))}
            </ul>
        </main>
    );
}