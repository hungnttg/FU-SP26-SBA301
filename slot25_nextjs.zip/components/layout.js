import Link from "next/link";
import React from "react";
export default function Layout({children}){
    return(
        <div style={{fontFamily:"ui-sans-serif"}}>
            <header style={{padding:"10px",backgroundColor:"#f0f0f0"}}>
                <nav style={{display:"flex",gap:"20px"}}>
                    <Link href="/">Home</Link>
                    <Link href="/about">About</Link>
                    <Link href="/blog">Blog</Link>
                </nav>
            </header>
            <main style={{padding:"20px"}}>{children}</main>
            <footer style={{padding:"10px",backgroundColor:"#f0f0f0",marginTop:"20px"}}>
                &copy; 2026 My Website
            </footer>
        </div>
    );
}