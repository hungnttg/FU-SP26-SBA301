import React,{useEffect,useState} from "react";
function Content2(){
    const [products,setProducts]=useState([]);
    const [visible,setVisible]=useState(6);//so san pham hien thi
    useEffect(()=>{
        fetch("https://hungnttg.github.io/shopgiay.json")
        .then((res)=>res.json())
        .then((data)=>{
            if(data && Array.isArray(data.products)){
                setProducts(data.products);
            }
            else {
                console.error("API khong tra ve du lieu: ");
            }
        })
        .catch((err)=>console.error("Error fetching data: ",err));
    },[]);
    const loadMore = () => setVisible((prev)=>prev+6);
    return(
        <section className="content-box">
            <h2>Content Section 2</h2>
            <div className="grid">
                {Array.isArray(products) &&
                products.slice(0,visible).map((item)=>(
                    <div key={item.styleid} className="card">
                        <img src={item.search_image} />
                        <h3>{item.brands_filter_facet}</h3>
                        <p>{item.product_additional_info}</p>
                        <p><strong>Price: </strong>{item.price}d</p>
                    </div>
                ))
                
                }
            </div>
            {Array.isArray(products) && visible < products.length && (
            <button className="load-more" onClick={loadMore}>Load More</button>
            )}
            {/* viet css truc tiep */}
            <style>{`
            .grid {
  display: grid;
  grid-template-columns: repeat(auto-fill,minmax(180px,));
  gap: 15px;
  margin-top: 15px;
}
.card {
  background: #f4caca;
  border-radius: 10px;
  overflow: hidden;
  text-align: center;
  transition: transform 0.3s, box-shadow 0.3s;
  cursor: pointer;
  padding: 12px;
}
  .card:hover img {
  transform: scale(1.1);
}
            
            `}</style>
        </section>
    );
}
export default Content2;