export default function About(){
    return(
        <div>
            <h2>About Us</h2>
            <p>This website is build with next js</p>
        </div>
    );
}