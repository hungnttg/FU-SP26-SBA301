import React, { createContext, useReducer, useContext, useState } from "react";

// 1. tạo context
const TodoContext = createContext();

// 2. reducer
function reducer(state, action) {
  switch (action.type) {
    case "ADD":
      return [...state, action.payload];

    case "DELETE":
      return state.filter((item) => item.id !== action.id);

    default:
      return state;
  }
}

// 3. provider
function TodoProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, []);
  return (
    <TodoContext.Provider value={{ state, dispatch }}>
      {children}
    </TodoContext.Provider>
  );
}

// 4. component chính
function TodoApp() {
  const { state, dispatch } = useContext(TodoContext);
  const [text, setText] = useState("");

  return (
    <div style={{ padding: 20 }}>
      <h2>Todo App (Context + Reducer)</h2>

      <input
        placeholder="Nhập công việc..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />

      <button
        onClick={() => {
          if (text.trim() === "") return;

          dispatch({
            type: "ADD",
            payload: {
              id: Date.now(),
              text: text,
            },
          });

          setText("");
        }}
      >
        Thêm
      </button>

      <ul>
        {state.map((item) => (
          <li key={item.id}>
            {item.text}
            <button
              onClick={() =>
                dispatch({ type: "DELETE", id: item.id })
              }
              style={{ marginLeft: 10 }}
            >
              Xóa
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// 5. export
export default function App() {
  return (
    <TodoProvider>
      <TodoApp />
    </TodoProvider>
  );
}