//ap dung layout cho toan bo trang
import Layout from "../components/layout";
import "../styles/globals.css";//neu co
export default function MyApp({Component,pageProps}){
    return(
        <Layout>
            <Component {...pageProps}/>
        </Layout>
    );
}
//khi nay moi trang trong pages se tu dong dung layout