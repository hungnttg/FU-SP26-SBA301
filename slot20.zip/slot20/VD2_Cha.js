//cha: quan ly state
//con: nhan props tu cha
import React,{useState} from "react";
import VD2_Con from "./VD2_Con";
export default function VD2_Cha(){
    //code
    const [msg,setMsg]=useState("Xin chao!");
    //layout
    return(
        <div>
            <VD2_Con message={msg}/>
            <button onClick={()=>setMsg("Chao ban, minh thay doi lio chao")}>
                Change message
            </button>
        </div>
    );
}