import {BrowserRouter as Router, Routes,Route} from 'react-router-dom';
import React,{Suspense} from 'react';
const Slot35Home = React.lazy(()=>import('./Slot35Home'));
const Slot35About = React.lazy(()=>import('./Slot35About'));
export default function Slot35(){
    return(
        <Router>
            <Suspense fallback={<div>Dang tai trang...</div>}>
                <Routes>
                    <Route path='/Slot35Home' element={<Slot35Home/>} />
                    <Route path='/Slot35About' element={<Slot35About/>} />
                </Routes>
            </Suspense>
        </Router>
        
    );
}
//xu ly lazy load theo tung route => phu hop voi dung dunng SPA lon