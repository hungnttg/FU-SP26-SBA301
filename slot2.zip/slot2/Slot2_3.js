//form ddawng kys
import { useState } from "react";
const Slot2_3 = () =>{
    //code
    const [username,setUsername]=useState("");
    const [age,setAge]=useState("");
    const handleSubmit = (e) =>{
        e.preventDefault();//cam cac hanh dong sumit mac dinh
        alert(`Xin chao ${username}, tuoi: ${age}`);
    };
    //layout
    return(
        <form onSubmit={handleSubmit}>
            <h2>Form dang ky</h2>
            <input
                type="text"
                placeholder="Nhap ten..."
                value={username}
                onChange={(e)=>setUsername(e.target.value)}
            />
            <br/>
            <input
                type="number"
                placeholder="Nhap tuoi..."
                value={age}
                onChange={(e)=>setAge(e.target.value)}
            />
            <br/>
            <button type="submit">Dang ky</button>
        </form>
    );
}
export default Slot2_3;