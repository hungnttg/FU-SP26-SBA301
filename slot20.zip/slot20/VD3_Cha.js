import React from "react";
import Student from "./VD3_Con";
export default function VD3_Cha(){
    //doc du lieu tu API
    const students =[
        {id:1,name:"Nguyen Van A", age:21, major:"KTPM"},
        {id:2,name:"TRan Van B", age:20, major:"KTPM"},
        {id:3,name:"Vu Van C", age:21, major:"KTPM"},
        {id:4,name:"Nguyen Thi D", age:19, major:"KTPM"},
    ];
    return(
        <div>
            <h1>Danh sach sinh vien</h1>
            {students.map((s)=>(
                <Student
                    key={s.id}
                    name={s.name}
                    age={s.age}
                    major={s.major}
                />
            ))}
        </div>
    );
}