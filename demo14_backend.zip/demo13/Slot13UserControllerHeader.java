package com.example.demo13;


import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.reactive.WebFluxLinkBuilder.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Arrays;
import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/slot13/users")
@CrossOrigin(origins = "http://localhost:3000") // cho phép ReactJS
public class Slot13UserControllerHeader {
    @Autowired
    SLot13UserRespository repo;
    @GetMapping(headers = "X-API-VERSION=1")
    public List<Slot13User> getUsersV1() {
        return Arrays.asList(
                new Slot13User(1L, "John", "john@example.com"),
                new Slot13User(2L, "Jane", "jane@example.com")
        );
    }

    @GetMapping(headers = "X-API-VERSION=2")
    public List<Slot13User> getUsersV2() {
        return Arrays.asList(
                new Slot13User(1L, "John", "JOHN@EXAMPLE.COM"),
                new Slot13User(2L, "Jane", "JANE@EXAMPLE.COM")
        );
    }
//    @PostConstruct
//    public void initData(){
//        if(repo.count()==0){
//            repo.save(new Slot13User(1L, "John", "JOHN@EXAMPLE.COM"));
//            repo.save(new Slot13User(2L, "Jane", "JANE@EXAMPLE.COM"));
//        }
//    }
//    @GetMapping("/{id}")
//    public EntityModel<Slot13User> getUser(@PathVariable Long id){
//        Slot13User user = repo.findById(id).orElseThrow(()->new RuntimeException("User not found with that is"));
//        return EntityModel.of(user,
//                linkTo(methodOn(Slot13UserControllerHeader.class).getUser(id)).withSelfRel(),
//                linkTo(methodOn(Slot13UserControllerHeader.class).updateUser(id,user)).withRel("update"),
//                linkTo(methodOn(Slot13UserControllerHeader.class).deleteUser(id)).withRel("delete")
//                );
//    }
//    @PutMapping("/{id}")
//    public Slot13User updateUser(@PathVariable Long id,@RequestBody Slot13User nUser){
//        //1. tim user cu
//        Slot13User user = repo.findById(id).orElseThrow(()-> new RuntimeException("Khong tim thay"));
//        //2. cap nhat
//        user.setName(nUser.getName());
//        user.setEmail(nUser.getEmail());
//        //3. luu
//        return repo.save(user);
//    }
//    @DeleteMapping("/{id}")
//    public ResponseEntity<?> deleteUser(@PathVariable Long id){
//        Slot13User user = repo.findById(id).orElseThrow(()->new RuntimeException("khong trim thay"));
//        repo.delete(user);
//        return ResponseEntity.noContent().build();
//    }
    //curl.exe -X DELETE "http://localhost:8081/slot13/users/1"
}