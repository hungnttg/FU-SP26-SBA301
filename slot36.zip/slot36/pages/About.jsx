//lazy load
import React from "react";
const About = () =>{
    return(
        <div>
            <h1>About Page</h1>
            <p>This page is lazy loaded!</p>
        </div>
    );
}
export default About;