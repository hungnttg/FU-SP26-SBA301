package com.example.slot15;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Slot15UserRepository extends MongoRepository<Slot15User,String> {
}
