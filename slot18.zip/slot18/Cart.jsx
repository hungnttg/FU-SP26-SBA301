import React,{useState} from "react";
import { createRoot } from "react-dom/client";
export default function Cart(){
    //state quan ly gio hang
    const [items, setItems]=useState([]);
    //danh sach san pham mau
    const sampleProducts = [
        {id:1,name:"Tao"},
        {id:2,name:"Cam"},
        {id:3, name: "Xoai"}
    ];
    //ham them san pham vao gio hang
    const addItem = (product) =>{
        setItems([...items,product]);
    };
    //ham xoa san pham khoi gio hang theo id
    const removeItem = (id) =>{
        setItems(items.filter((item)=>item.id !== id));
    };
    //xoa toan bo gio hang
    const clearCart = () =>{
        setItems([]);
    };
    //giao dien
    return(
        <div style={{padding: 20, fontFamily:"sans-serif"}}>
            <h1>Gio hang</h1>
            {/* danh sach san pham */}
            <h2>San pham co san</h2>
            {sampleProducts.map((product)=>(
                <div key={product.id}>
                    {product.name}{" "}
                    <button onClick={()=> addItem(product)}>Add to Cart</button>
                </div>
            ))}
            {/* gio hang */}
            <h2>Gio hang</h2>
            {items.length === 0 ? (
                <p>Chua cos san pham</p>
            ) :(
                <ul>
                    {items.map((item,index)=>(
                        <li key={index}>
                            {item.name}{" "}
                            <button onClick={()=>removeItem(item.id)}>Xoa</button>
                        </li>
                    ))}
                </ul>
            )}
            {/* hoa het gio hang */}
            {items.length > 0 && (
                <button onClick={clearCart}>Xoa het gio hang</button>
            )}
        </div>
    );

}
