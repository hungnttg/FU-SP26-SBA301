//React.lazy +Suspense
import React,{Suspense,lazy} from "react";
import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import Home from "./pages/Home";
import LoadingSpinner from "./components/LoadingSpinner";
//lazy load About and COntact pages
const About = lazy(()=>import('./pages/About'));
const Contact = lazy(()=> import('./pages/Contact'));
export default function Sl36(){
    return(
        <Router>
            <Suspense fallback={<LoadingSpinner/>}>
                <Routes>
                    <Route path="/" element={<Home/>}/>
                    <Route path="/about" element={<About/>}/>
                    <Route path="/contact" element={<Contact/>}/>
                </Routes>
        </Suspense>
        </Router>
        
    );
}
