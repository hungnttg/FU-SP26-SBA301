import { Link } from "react-router-dom";
export default function Home(){
    return(
        <div className="container">
            <h2>Trang chu</h2>
            <p>Chao mung cac ban</p>
            <Link to={"/about"}>Xem trang gioi thieu</Link>
        </div>
    );
}