// hien thi thoi gian hien tai
const Slot2_1 = () =>{
    //code
    const now = new Date().toLocaleTimeString();
    //layout
    return(
        <div>
            <h2>Bay gio la: {now}</h2>
        </div>
    );
}
export default Slot2_1;