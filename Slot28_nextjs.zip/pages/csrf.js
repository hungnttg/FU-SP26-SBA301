//an toan
export default function Home(){
    const handleSubmit = async (e) =>{
        e.preventDefault();//chong gui form mac dinh
        //doc du lieu tu API thi nen lam nhu sau
        const res = await fetch("/api/submit",{
            method: "POST",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify({csrfToken: "1234567"}),
            //khi thu thay token la 1234567 => khong gui duoc
        });
        alert((await res.json()).message);
    };
    return(
        <div style={{padding:40}}>
            <h3>Demo CSRF don gian</h3>
            <form onSubmit={handleSubmit}>
                <button type="submit">Gui du lieu</button>
            </form>
        </div>
    );
}