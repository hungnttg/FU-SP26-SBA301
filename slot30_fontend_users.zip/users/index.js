"use client";
import { useEffect,useState } from "react";
export default function UsersPage(){
    const [users,setUsers]=useState([]);
    const [form,setForm]=useState({name:"",email:""});
    //load du lieu
    useEffect(()=>{
        fetch("http://localhost:8081/slot30/api/users")
        .then((res)=>res.json())
        .then((data)=>setUsers(data))
        .catch((err)=>console.error(err));
    },[]);
    //ham submit
    const handleSubmit = async (e) =>{
        e.preventDefault();//chan gui mac dinh
        const res = await fetch("http://localhost:8081/slot30/api/users",{
            method:"POST",
            headers: {"Content-Type":"application/json"},
            body:JSON.stringify(form),
        });
        const newUser = await res.json();
        setUsers([...users,newUser]);
        setForm({name:"",email:""});
    };
    return(
        <div style={{padding:20}}>
            <h1>Danh sach nguoi dung</h1>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Ten"
                    value={form.name}
                    onChange={(e)=>setForm({...form,name:e.target.value})}
                    required
                />
                <input
                    type="email"
                    placeholder="email"
                    value={form.email}
                    onChange={(e)=>setForm({...form,email:e.target.value})}
                    required
                />
                <button type="submit">Them</button>
            </form>
            <ul>
                {users.map((u)=>(
                    <li key={u.id}>
                        {u.name} - {u.email}
                    </li>
                ))}
            </ul>
        </div>
    );
}