import React from "react";
export default function Slot21_Cart({items}){
    const total = items.reduce(
        (sum,item) => sum + item.price * item.quantity,0
    );
    return(
        <div style={{marginTop:"20px"}}>
            <h2>Gio hang co {items.length} san pham </h2>
            <ul>
                {items.map((item,index)=>(
                    <li key={index}>{item.name} 
                    - {item.price.toLocaleString()}VND x {item.quantity}</li>
                ))}
            </ul>
            <h3>
                Tong tien: {total.toLocaleString()}VND
            </h3>
        </div>
    );
}