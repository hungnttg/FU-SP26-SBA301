//anh responsive, co placeholder blur de trai nghiem tot hon khi dang load
//react se tu dong chon dinh dang webP, avif neu trinh duyet ho tro
import Image from "next/image";
export default function ImageAdvanced(){
    return(
        <main style={{padding:20}}>
            <h1>Demo toi uu hinh anh nang cao</h1>
            <Image
                src="https://images.unsplash.com/photo-1761602545461-7c9bd9a986df?q=80&w=1311&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                quality={100}
                width={400}
                height={400}
                placeholder="blur"
                blurDataURL="https://placehold.co/400"
                style={{borderRadius:"15px",maxWidth:'100%',height:'auto'}}
            />
        </main>
    );
}