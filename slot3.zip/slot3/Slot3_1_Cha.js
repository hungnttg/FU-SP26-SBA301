//thanh phan cha
//goi thanh phan con
import Slot3_1_Con from "./Slot3_1_Con";
export default function Slot3_1_Cha(){
    return(
        <div>
            <h1>Demo props</h1>
            {/* goi thanh phan con va truyen du lieu qua props name, age */}
            <Slot3_1_Con name="An" age={20} />
            <Slot3_1_Con name="Binh" age={21}/>
        </div>
    );
}