//su dung bootstrap de dinh dang
import Button from "react-bootstrap/Button";
import 'bootstrap/dist/css/bootstrap.min.css';
export default function Slot4_2(){
    return(
        <div style={{padding:"20px"}}>
            <h1>Demo bootstrasp</h1>
            <Button variant="primary">primary</Button>{' '}
            <Button variant="success">success</Button>{' '}
            <Button variant="danger">danger</Button>{' '}
            <Button variant="outline-dark">outline</Button>{' '}

        </div>
    );
}