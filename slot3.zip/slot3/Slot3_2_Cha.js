//cha goi den con va truyen du lieu vao props
import Slot_3_2_Con from "./Slot3_2_Con";
export default function Slot3_2_Cha(){
    return(
        <div>
            <h1>Demo children props</h1>
            {/* cha goi con lan 1 */}
            <Slot_3_2_Con>
                <p>Noi dung trong props con</p>
            </Slot_3_2_Con>
            {/* cha goi con lan 2 */}
            <Slot_3_2_Con>
                <button>Click me</button>
            </Slot_3_2_Con>
        </div>
    );
}