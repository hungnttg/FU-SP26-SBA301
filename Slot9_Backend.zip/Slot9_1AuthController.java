package com.example.demo1;

import org.springframework.web.bind.annotation.*;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class Slot9_1AuthController {
    @PostMapping("/login")
    public Map<String, String> login(@RequestParam String username,
                                     @RequestParam String password) {
        Map<String, String> result = new HashMap<>();
        if(("admin".equals(username) && "admin".equals(password)) ||
                ("user".equals(username) && "user".equals(password))) {
            String role = "admin".equals(username) ? "ADMIN" : "USER";
            String token = Base64.getEncoder().encodeToString((username + ":" + role).getBytes());
            result.put("token", token);
            result.put("role", role);
        } else {
            result.put("error", "Invalid credentials");
        }
        return result; // JSON đúng định dạng
    }
}
