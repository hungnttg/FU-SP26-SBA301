import { Link } from "react-router-dom";
export default function About(){
    return(
        <div className="container">
            <h2>Gioi thieu</h2>
            <p>Day la trang gioi thieu</p>
        </div>
    );
}