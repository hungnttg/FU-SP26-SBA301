// import React from "react";
// import ReactDOM from 'react-dom/client';
// import Sl36 from "./Sl36";
// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//     <React.StrictMode>
//         <Sl36/>
//     </React.StrictMode>
// );