import { BrowserRouter,Routes,Route } from "react-router-dom"
import ShopList from "./components/ShopList";
import ShopDetail from "./components/ShopDetail";

export default function App(){
  return(
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ShopList/>} />
        <Route path="/view/:id" element={<ShopDetail/>} />
      </Routes>
    </BrowserRouter>
  );
}