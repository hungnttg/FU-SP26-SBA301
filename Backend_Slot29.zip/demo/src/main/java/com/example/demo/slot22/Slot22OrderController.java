package com.example.demo.slot22;

import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3001")
@RestController
@RequestMapping("/slot22/orders")
public class Slot22OrderController {
    @GetMapping("/create/{id}")
    public String createOrder(@PathVariable int id){
        return "Slot22: Don hang cho san pham ID "+id+" da duoc tao!";
    }
}
