//render moi khi dependency thay doi
import { useState,useEffect } from "react";
export default function Slot6_2(){
    //code
    const [userId,setUserId]=useState(1);
    const [posts,setPosts]=useState([]);
    //doc du lieu oi khi dependency thay doi
    useEffect(()=>{
        fetch(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`)
        .then((res)=>res.json())
        .then((data)=>setPosts(data));
    },[userId]);
    //layout
    return(
        <div style={{padding:"20px"}}>
            <h1>Bai post cua user {userId}</h1>
            <button onClick={()=>setUserId(1)}>User 1</button>
            <button onClick={()=>setUserId(2)}>User 2</button>
            <button onClick={()=>setUserId(3)}>User 3</button>
            {/* du lieu hien thi cho moi user */}
            <ul>
                {posts.map((p)=>(
                    <li key={p.id}>{p.title}</li>
                ))}
            </ul>
        </div>
    );
}