//dinh dang bang bang bootstrap
import { Container } from "react-bootstrap";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import  Card  from "react-bootstrap/Card";
export default function Slot4_3(){
    return(
        <Container>
            <h1 className="mt-3">Demo Table</h1>
            <Row>
                <Col md={4}>
                    <Card>
                        <Card.Body>Cot 1</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Cot 2</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Cot 3</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Cot 4</Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}