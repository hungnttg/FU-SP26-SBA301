//Modal: hien thi chi tiet san pham
import { useState } from "react";
import { Button } from "react-bootstrap";
import { Modal } from "react-bootstrap";
export default function Slot5_3(){
    const [show,setShow]=useState(false);
    //quan ly khi nao show, khi nao close
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    //giao dien
    return(
        <div style={{padding:"20px"}}>
            <Button variant="info" onClick={handleShow}>Chi tiet</Button>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Thong tin san pham</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Day la chi tiet cua san pham
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>Dong</Button>
                    <Button variant="primary" onClick={handleClose}>Mua ngay</Button>
                </Modal.Footer>
            </Modal>
        </div>
        
    );
}