//React.memo giups component chi render khi props thay doi
import React from "react";
const Counter = React.memo(({count,onIncrement})=> {
    console.log('Render Counter');
    return(
        <div>
            <h2>Counter: {count}</h2>
            <button onClick={onIncrement}>Increment</button>
        </div>
    );
});
export default Counter;