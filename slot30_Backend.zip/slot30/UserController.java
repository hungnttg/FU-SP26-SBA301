package com.example.slot30;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/slot30/api/users")
public class UserController {
    private final UserRepository repo;
    public UserController(UserRepository repo){
        this.repo=repo;
    }
    @GetMapping
    public List<User> getAll(){
        return repo.findAll();
    }
    @PostMapping
    public User addUser(@RequestBody User user){
        return repo.save(user);
    }
}
