package com.example.demo.slot29;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot29Application {
    public static void main(String[] args) {
        SpringApplication.run(Slot29Application.class,args);
    }
}
