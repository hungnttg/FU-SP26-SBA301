import React,{useState} from "react";
import Slot21_Cart from "./Slot21_Cart";
import Slot21_ProductList from "./SLot21_ProductList";
export default function Slot21(){
    const [cart,setCart]=useState([]);
    //doc du lieu
    const products=[
        {id:1,name:"Iphone 17",price: 50000000},
        {id:2,name:"Iphone 17 pro",price: 55000000},
        {id:3,name:"Iphone 17 promax",price: 60000000},
    ];
    //dinh nghia ham addToCart
    const addToCart = (product) => {
        //setCart([...cart,product]);
        setCart((prev) => {
            const tontai = prev.find(item => item.id === product.id);
            if(tontai){
                return prev.map(item =>
                    item.id === product.id
                    ? {...item,quantity: item.quantity + 1} : item
                );
            }
            return [...prev,{...product,quantity:1}];
        });
    };
    //giao dien
    return(
        <div>
            <h1>Cua hang dien thoai ABC</h1>
            <Slot21_ProductList products={products} addToCart={addToCart}/>
            <Slot21_Cart items={cart}/>
        </div>
    );
}