//trang home
export default function Home(){
    return(
        <div>
            <h2>Chao mung cac ban den voi my website</h2>
            <p>This is the homepage content.</p>
        </div>
    );
}