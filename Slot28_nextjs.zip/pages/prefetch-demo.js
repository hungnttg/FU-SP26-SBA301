//dieu khien thu cong viec chuyen trang de tang hieu suat
import Link from "next/link";
export default function PrefetchDemo(){
    return(
        <main style={{padding:20}}>
            <h1>Demo prefetch</h1>
            <p>Nhan vao cac link duoi day de xem toc do chuyen trang</p>
            {/* tu dong prefetch khi xuat hien trong viewport */}
            <Link href="/posts" prefetch={true}>
                <button style={{marginRight:10}}>
                    Den trang bai viet (prefetch on)
                </button>
            </Link>
            {/* tat prefetch de so sanh */}
            <Link href="/chart" prefetch={false}>
                <button>Den trang bieu do (prefetch off)</button>
            </Link>
        </main>
    );
}