import { Link } from "react-router-dom";
export default function Contact(){
    return(
        <div className="container">
            <h2>LIen he</h2>
            <p>Email: contact@gmail.com</p>
            <p>Mobile: 0912345678</p>
        </div>
    );
}