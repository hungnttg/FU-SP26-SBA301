//npm i react-router-dom
import "./App17.css";
import { Link, Route,BrowserRouter as Router, Routers, Routes } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import ProductDetail from "./pages/ProductDetail";
import Products from "./pages/Products";
import Posts from "./pages/Posts";
import PostDetail from "./pages/PostDetail";
export default function App17(){
    return(
        <Router>
            <nav>
                <Link to="/">Home</Link>
                <Link to="/about">Gio thieu</Link>
                <Link to={"/contact"}>Lien he</Link>
                <Link to="/products">San pham</Link>
                <Link to="/posts">Posts</Link>
            </nav>
            <Routes>
               <Route path="/" element={<Home/>} />
               <Route path="/about" element={<About/>} />
                <Route path="/contact" element={<Contact/>} />
                <Route path="/products" element={<products/>} />
                <Route path="/products/:id" element={<ProductDetail/>} />
                <Route path="/posts" element={<Posts/>} />
                <Route path="/posts/:id" element={<PostDetail/>} />
            </Routes>
        </Router>
    );
}