import React,{Suspense} from "react";
//lazy load component
const UserProfile = React.lazy(()=>import('./Slot35Home'));
export default function Slot35_2(){
    return(
        <div>
            <h1>Trang chinh</h1>
            {/* Suspense cho phep hien thi fallback khi component dang load */}
            <Suspense fallback={<div>Dang tai.....</div>}>
                <UserProfile/>
            </Suspense>
        </div>
        
        
    );
}
// Khi App chay, userProfile se khong duoc tai ngay
//=>tai khi component duoc render
//=>react se tao 1 bundle rieng cho UserProfile
//=> tu dong tai xuong khi duoc goi
