/** @type {import('next').NextConfig} */
const nextConfig = {
  /* config options here */
  images: {
    domains: ['images.unsplash.com'],
    formats: ['image/avif','image/webp'],
  },
  reactCompiler: true,
};

export default nextConfig;
