import React from "react";
export default function XinChao(props){
    return(
        <div>
            <h2>Xin chao {props.name}, gioi tinh cua ban la {props.gender}</h2>
        </div>
    );
}