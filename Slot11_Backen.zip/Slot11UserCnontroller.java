package com.example.demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

@RestController
@RequestMapping("/slot11user")
@CrossOrigin(origins = "http://localhost:3000")
public class Slot11UserCnontroller {
    @Autowired
    private Slot11UserService service;
    @Bean
    public WebMvcConfigurer corsConfigurer(){
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:3000")
                        .allowedMethods("GET","POST","PUT","DELETE","OPTIONS");
            }
        };
    }
    @GetMapping
    public List<Slot11User> getAll(){
        return service.getAll();
    }
    @GetMapping("/{id}")
    public Slot11User getById(@PathVariable Long id){
        return service.getById(id).orElse(null);
    }
    @PostMapping
    public Slot11User create(@RequestBody Slot11User u){
        return service.create(u);
    }
    @PutMapping("/{id}")
    public Slot11User update(@PathVariable Long id,@RequestBody Slot11User u){
        return service.update(id,u);
    }
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id){
        service.delete(id);
        return "Deleteed SLot11User id="+id;
    }
}
