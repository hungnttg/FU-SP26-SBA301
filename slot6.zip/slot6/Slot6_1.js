//goi API 1 làn khi mount
import { useState,useEffect } from "react";
export default function Slot6_1(){
    //code
    const [posts,setPosts]=useState([]);
    //goi 1 lan khi mount
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts?_limit=10")
        .then((res)=>res.json()) //chuyen kq sang json
        .then((data)=>setPosts(data));//do du lieu vao bien posts
    },[]);
    //layout
    return(
        <div style={{padding:"20px"}}>
            <h1>Danh sach bai viet</h1>
            <ul>
                {posts.map((p)=>(
                    <li key={p.id}>{p.title}</li>
                ))}
            </ul>
        </div>
    );
}