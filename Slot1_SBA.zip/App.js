import logo from './logo.svg';
import './App.css';
import Slot1_1 from './slot1/Slot1_1'; //import component
import Slot1_2 from './slot1/Slot1_2';
function App() {
  return (
    <div className="App">
      {/* goi component */}
      <Slot1_2/>
    </div>
  );
}

export default App;
