import React from "react";
import XinChao from "./VD1_Con";
export default function VD1_Cha(){
    return(
        <div>
            <XinChao name="An" gender="Nam"/>
            <XinChao name="HUyen" gender="Nu"/>
        </div>
    );
}