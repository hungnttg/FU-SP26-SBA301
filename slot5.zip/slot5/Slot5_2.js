//form dang nhap
import { Form } from "react-bootstrap";
import {Button} from "react-bootstrap";
export default function Slot5_2(){
    return(
        <div style={{width: "300px",margin: "60px auto"}}>
            <h2>Dang nhap</h2>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Email</Form.Label>
                    <Form.Control type="email" placeholder="Nhap email" />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>Mat khau</Form.Label>
                    <Form.Control type="password" placeholder="Nhap pass" />
                </Form.Group>
                <Button variant="primary" type="submit">Dang nhap</Button>
            </Form>
        </div>
    );
}