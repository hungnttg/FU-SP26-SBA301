//cai dat thu vien
//npm i @reduxjs/toolkit react-redux
//reduxjs/toolkit => cung cap config giup viec viet redux nhanh
//react-redux: kết noi react voi redux (useSelector,useDispatch)
import React from "react";
import { configureStore,createSlice } from "@reduxjs/toolkit";
import { Provider,useDispatch,useSelector } from "react-redux";
//-----
//dinh nghia cac ham co the co (action, reducer)
const cartSlice = createSlice({
    name: "cart",
    initialState:{
        items: [],//danh sach san pham
    },
    reducers: { //dinh nghia ham
        addItem : (state,action) =>{
            state.items.push(action.payload);//them san pham vao gio hang
            //action: hanh dong nao
            //payload: du lieu cho action tuong tac
        },
        removeItem: (state,action) =>{
            state.items = state.items.filter((item)=> item.id !== action.payload);
        },
        clearCart: (state) =>{
            state.items = [];//xoa gio hang
        },
    },
});
//tao store de cau hinh va luu tru state
const store = configureStore({reducer: cartSlice.reducer});//cau hinh hanh dong cho state
const {addItem, removeItem, clearCart}= cartSlice.actions;//gan cacs hanh dong
//=====UI component===
function CartUI(){
    const items = useSelector((state)=> state.items);
    const dispatch = useDispatch();
    // du lieu test
    const sampleProducts = [
        {id: 1, name: "Tao"},
        {id: 2, name: "Cam"},
        {id: 3, name: "Xoai"}
    ];
    //giao dien
    return(
        <div style={{padding:20}}>
            <h1>Gio hang</h1>
            <h2>San pham co san</h2>
            {sampleProducts.map((product)=>(
                <div key={product.id}>
                    {product.name}{" "}
                    <button onClick={()=> dispatch(addItem(product))}>Them vao gio hang</button>
                </div>
            ))}
            {/* gio hang */}
            <h2>Gio hang</h2>
            {items.length === 0 ? (
                <p>Khong co san pham nao</p>
            ):(
                <ul>
                    {items.map((item)=>(
                    <li key={item.id}>
                        {item.name}{" "}
                        <button onClick={()=>dispatch(removeItem(item.id))}>Xoa</button>
                    </li>
                ))}
                </ul>
                
            )}
            {items.length > 0 && (
                <button onClick={()=> dispatch(clearCart())}>Xoa toan bo gio hang</button>
            )}
        </div>
    );
}
//export
export default function Cart(){
    return(
        <Provider store={store}>
            <CartUI/>
        </Provider>
    );
}