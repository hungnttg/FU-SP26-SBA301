//npm i react-bootstrap axios react-router-dom
import { useState,useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Modal,Form,Button,Table, FormControl } from "react-bootstrap";
import axios from "axios";
export default function ShopList(){
    const [shops,setShops]=useState([]);
    const [form,setForm]=useState({shopName:"",owner:"",type:"",openTime:""});
    const [show,setShow]=useState(false);
    const [types,setTypes]=useState([]);
    const [deleteId,setDeleteId]=useState(null);
    const API = "http://localhost:8080/slot29/shops";
    const navigate = useNavigate();
    useEffect(()=>{
        docDuLieu();
        //dien vao type
        axios.get("http://localhost:8080/slot29/shop/types").then(res=>setTypes(res.data));
    },[]);
    //dinh nghia ham doc dulieu
    const docDuLieu=() => axios.get(API).then(response=>setShops(response.data));
    //them du lieu
    const handleAdd = () =>{
        if(!form.shopName || !form.type || !form.owner || !form.openTime){
            alert("Xin moi ban nhap du lieu");
            return;
        }
        axios.post(API,form).then(()=>{
            alert("Them du lieu thanh cong");
            docDuLieu();//reload
        });
    };
    //ham xoa du lieu
    const handleXoa = () =>{
        axios.delete(`${API}/${deleteId}`).then(()=>{
            alert("Xoa thanh cong");
            setShow(false);
            docDuLieu();
        });
    };
    //confirm xoa
    const confirmXoa = (id) =>{
        setDeleteId(id);
        setShow(true);
    };
    //giao dien
    return(
        <div className="container mt-3">
            <h2>Quan ly shop sach</h2>
            <Form className="mb-3">
                <Form.Control
                    placeholder="Shop name"
                    value={form.shopName}
                    onChange={(e)=>setForm({...form,shopName:e.target.value})}
                    className="mb-2"
                />
                <Form.Control
                    placeholder="Owner"
                    value={form.owner}
                    onChange={(e)=>setForm({...form,owner:e.target.value})}
                    className="mb-2"
                />
                <Form.Select
                    value={form.type}
                    onChange={(e)=>setForm({...form,type:e.target.value})}
                    className="mb-2"
                >
                    <option value="">Select Type</option>
                    {types.map(t=><option key={t}>{t}</option>)}
                </Form.Select>
                <Form.Control
                    placeholder="Open time"
                    type="number"
                    value={form.openTime}
                    onChange={(e)=>setForm({...form,openTime:e.target.value})}
                    className="mb-2"
                />
                <Button onClick={handleAdd}>Them moi</Button>
            </Form>
            <Table bordered>
                <thead>
                    <tr>
                        <th>#No</th>
                        <th>Shop Name</th>
                        <th>Type</th>
                        <th>Owner</th>
                        <th>OpenTime</th>
                        <th>Action</th>
                    </tr>
                </thead>
                    <tbody>
                        {shops.map((s,i)=>(
                            <tr key={s.id}>
                                <td>{i+1}</td>
                                <td>{s.shopName}</td>
                                <td>{s.type}</td>
                                <td>{s.owner}</td>
                                <td>{s.openTime}</td>
                                <td>
                                    <Button variant="danger" size="sm"
                                    onClick={()=>confirmXoa(s.id)}>Delete</Button>{" "}
                                    <Button variant="info" size="sm"
                                    onClick={()=>navigate(`/view/${s.id}`)}>View</Button>{" "}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                
            </Table>
            <Modal show={show} onHide={()=>setShow(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Xoa</Modal.Title>      
                </Modal.Header>
                <Modal.Body>Ban co muon xoa khong?</Modal.Body>  
                <Modal.Footer>
                    <Button onClick={handleXoa}>Yes</Button>
                    <Button variant="secondary" onClick={()=>setShow(false)}>Close</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}