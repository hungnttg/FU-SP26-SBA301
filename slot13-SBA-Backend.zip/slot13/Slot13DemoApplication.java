package com.example.t1.slot13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot13DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(Slot13DemoApplication.class, args);
    }
}
