package com.example.demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Slot11UserService {
    @Autowired
    private Slot11UserRepository repo;
    public List<Slot11User> getAll(){
        return repo.findAll();
    }
    public Optional<Slot11User> getById(Long id){
        return repo.findById(id);
    }
    public Slot11User create(Slot11User u){
        return repo.save(u);
    }
    public Slot11User update(Long id,Slot11User u){
        return repo.findById(id).map(user->{
            user.setName(u.getName());
            user.setBirthday(u.getBirthday());
            return repo.save(user);
        }).orElse(null);
    }
    public void delete(Long id){
        repo.deleteById(id);
    }
}
