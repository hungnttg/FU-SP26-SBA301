//dem so lan click
import { useState } from "react";
const Slot2_2 = () =>{
    //code
    const [count, setCount] = useState(0);//khi chua click, bien dem=0
    //layout
    return(
        <div>
            <h2>Ban da click {count} lan.</h2>
            <button onClick={()=>setCount(count+1)}>Tang</button>
            <button onClick={()=>setCount(count-1)}>Giam</button>
            <button onClick={()=>setCount(0)}>Reset</button>
        </div>
    );
}
export default Slot2_2;