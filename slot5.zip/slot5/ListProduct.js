import React from "react";
import { FlatList, View } from "react-native";
import Product from "./Product";

export default class ListProduct extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            products: [],
        };
    }

    componentDidMount(){
        this.getProducts();
    }

    async getProducts(){
        const url = 'https://hungnttg.github.io/shopgiay.json';
        let response = await fetch(url);
        let responseJSON = await response.json();
        this.setState({
            products: responseJSON.products,
        });
    }

    renderItem = ({ item }) => (
        <Product dataProd={item} />
    );

    render(){
        return (
            <View style={{ flex: 1 }}>
                <FlatList
                    data={this.state.products}
                    renderItem={this.renderItem}
                    numColumns={3}
                    keyExtractor={(item, index) => index.toString()}
                />
            </View>
        );
    }
}
