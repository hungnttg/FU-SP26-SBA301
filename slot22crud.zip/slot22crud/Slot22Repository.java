package com.example.slot22crud;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Slot22Repository extends JpaRepository<Slot22Product,Long> {
}
