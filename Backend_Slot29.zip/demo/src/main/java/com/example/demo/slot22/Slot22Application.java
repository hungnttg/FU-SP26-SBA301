package com.example.demo.slot22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot22Application {
    public static void main(String[] args) {
        SpringApplication.run(Slot22Application.class,args);
    }
}
