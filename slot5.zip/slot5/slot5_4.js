//Tao trang web ban hang
//co Navbar (Trang chu, san pham, gio hang)
//danh sach san pham (Card, Button, Xem chi tiet)
//Khi nhan vao xem chi tiet => hien thi modal
//them form dang nhap
import React, { useState } from "react";
import { Navbar,Nav,Container,Card,Button,Row,Col,Modal,Form } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
export default function Slot5_4(){
    const [showModal,setShowModal]=useState(false);
    const [selectedProduct,setSelectedProduct]=useState(null);
    const [showLogin,setShowLogin]=useState(false);
    const products = [
        {id:1,name:"San pham A",price:"100000",description:"Mo ta san pham A"},
        {id:2,name:"San pham B",price:"120000",description:"Mo ta san pham B"},
        {id:3,name:"San pham C",price:"110000",description:"Mo ta san pham C"},
    ];
    //ham hien thi chi tiet
    const handleShowDetail = (product) =>{
        setSelectedProduct(product);
        setShowModal(true);
    };
    //ham login
    const handleLoginSubmit = (e) =>{
        e.preventDefault();
        alert("Dang nhap thanh cong");
        setShowLogin(false);
    };
    //giao dien
    return(
        <>
            <Navbar bg="light" variant="light" expand="lg" fixed="top">
                <Container>
                    <Navbar.Brand href="#">MyShop</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            <Nav.Link href="#">Trang chu</Nav.Link>
                            <Nav.Link href="#">San pham</Nav.Link>
                            <Nav.Link href="#">Gio hang</Nav.Link>
                        </Nav>
                        <Button variant="outline-primary" onClick={()=>showLogin(true)}>
                            Dang nhap
                        </Button>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
            {/* hien thi san pham */}
            <div style={{marginTop:"80px"}}>
                <Container className="mt-4">
                    <Row>
                        {products.map((product) =>(
                            <Col key={product.id} md={4} className="mb-4">
                                <Card>
                                    <Card.Body>
                                        <Card.Title>{product.name}</Card.Title>
                                        <Card.Text>Gia: {product.price}</Card.Text>
                                        <Button variant="primary" onClick={()=>handleShowDetail(product)}>
                                            Xem chi tiet
                                        </Button>
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))}
                    </Row>
                </Container>
            </div>
            {/* viet modal chi tiet san pham */}
            <Modal show={showModal} onHide={()=>setShowModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>{selectedProduct?.name}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p><b>Gia: </b> {selectedProduct?.price}</p>
                    <p><b>Mo ta: </b> {selectedProduct?.description}</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={()=>setShowModal(false)}>Dong</Button>
                    <Button variant="success">Them vao gio hang</Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}