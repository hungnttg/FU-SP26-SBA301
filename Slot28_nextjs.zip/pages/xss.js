//trang khong an toan
//XSS: truyen ma doc vao js qua form
//muc dich: lay cap token, cookie
//vi du ve trang khong an toan
"use client";
import { useState } from "react";
export default function XSSBad(){
    const [comment,setComment]=useState("");
    return(
        <div>
            <h2>Binh luan KHONG an toan</h2>
            <input type="text" placeholder="Nhap binh luan"
            onChange={(e)=>setComment(e.target.value)}/>
            <p>Hien thi binh luan</p>
            {/* de bi hack bang XSS neu nhap <img src=x onerror="alert(1)"> /> */}
            {/* trang se tu chay ma cua hacker */}
            <div dangerouslySetInnerHTML={{__html:comment}} />
        </div>
    );
}