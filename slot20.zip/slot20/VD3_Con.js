import React from "react";
export default function Student(props){
    return(
        <div style={{border:"1px solid gray",padding:"10px",margin:"10px"}}>
            <h3>{props.name}</h3>
            <p>Tuoi: {props.age}</p>
            <p>Nganh: {props.major}</p>
        </div>
    );
}